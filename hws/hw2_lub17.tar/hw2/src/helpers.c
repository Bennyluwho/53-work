#include "helpers.h"

int heap_init = 0;
int pages_allocated = 0;
void *heap_start = NULL; 

/* Helper function definitions go here */
int init_heap_first_page(void) {
    void *page = ics_inc_brk();
    if (page == ((void *) -1)) return -1;
    pages_allocated++;
    heap_start = page;

    //since a char is 1 byte this will act as my pointer to the start of the page
    char *base = (char *) page;

    size_t H = sizeof(ics_header);
    size_t F = sizeof(ics_footer);

    size_t pro_size = H + F + 8;

    //initalize prologue: header + footer = 16 bytes
    ics_header *pro_h = (ics_header*) base;
    pro_h->block_size = pro_size;
    pro_h->hid = HEADER_MAGIC;
    pro_h->padding_amount = 0;

    ics_footer *pro_f = (ics_footer *)base;
    pro_f->fid = FOOTER_MAGIC;
    pro_f->block_size = PACK(0, 1, 0);

    //initalize epilogue header at the end of page (8 bytes)
    ics_header *epi_h = (ics_header *)(base + PAGE_SIZE - H);
    epi_h->hid = HEADER_MAGIC;
    epi_h->padding_amount = 0;
    epi_h->block_size = PACK(0, 1, 0);   

    //initial free block ptr RIGHT AFTER the prologue block (16 bytes after the starting address)
    ics_free_header *free_blk = (ics_free_header *)(base + F);

    //free block size is everything between the free_blk and epilouge
    size_t free_size = (size_t)((char *)epi_h - (char *)free_blk);

    free_blk->header.block_size = PACK(free_size, 0, 0);
    free_blk->header.hid = HEADER_MAGIC;
    free_blk->header.padding_amount = 0;

    free_blk->next = NULL;
    free_blk->prev = NULL;

    //initalize the free block's footer
    ics_footer *free_f = (ics_footer *) ((char *)free_blk + free_size - F);
    free_f->block_size = PACK(free_size, 0, 0);
    free_f-> fid = FOOTER_MAGIC;

    freelist_head = free_blk;
    heap_init = 1;
    return 0;
}

static void remove_free_block(ics_free_header *blk) {
    if(blk->prev != NULL) {
        blk->prev->next = blk->next;
    } else {
        freelist_head = blk->next;
    }

    if (blk->next != NULL) {
        blk->next->prev = blk->prev;
    }

    blk->next = NULL;
    blk->prev = NULL;
}

ics_free_header *find_fit(size_t needed) {
    ics_free_header *curr = freelist_head;
    ics_free_header *best = NULL;
    size_t best_sz = 0;

    while (curr != NULL) {
        size_t csz = GET_SIZE(curr->header.block_size);

        if (csz >= needed) {
            if (best == NULL || csz < best_sz || csz == best_sz) {
                best = curr;
                best_sz = csz;
            }
        }
        curr = curr->next;
    }
    return best;
}

void *place_block(ics_free_header *blk, size_t needed, size_t size) {
    size_t H = sizeof(ics_header);
    size_t F = sizeof(ics_footer);

    //minimum size for a free block
    size_t min_free = sizeof(ics_free_header) + F;

    size_t blk_size = GET_SIZE(blk->header.block_size);

    //detach this block from the free list
    remove_free_block(blk);

    //choose to either split or no split
    if (blk_size >= needed + min_free) {
    //SPLITS
        size_t pad = ALIGN(size) - size;
        int pbit = (pad > 0);

        //allocated block uses exactly what is 'needed' ;)
        blk->header.block_size = PACK(needed, 1, pbit);
        blk->header.hid = HEADER_MAGIC;

        //padding = aligned_payload - requested_payload
        blk->header.padding_amount = (uint64_t)pad;

        ics_footer *alloc_f = (ics_footer *)((char*)blk + needed - F);
        alloc_f->block_size = PACK(needed, 1, pbit);
        alloc_f->fid = FOOTER_MAGIC;

        //remainder free block located right after allocated block
        ics_free_header *rem = (ics_free_header *)((char *)blk + needed);
        size_t rem_size = blk_size - needed;

        rem->header.block_size = PACK(rem_size, 0, 0);
        rem->header.hid = HEADER_MAGIC;
        rem->header.padding_amount = 0;

        ics_footer *rem_f = (ics_footer*)((char *)rem + rem_size - F);
        rem_f->block_size = PACK(rem_size, 0, 0);
        rem_f->fid = FOOTER_MAGIC;

        rem->next = NULL;
        rem->prev = NULL;

        insert_free_block_ordered(rem);
    } else {
    //no split, avoids splinters
        size_t payload_cap = blk_size - (H + F);
        size_t pad = payload_cap - size;
        int pbit = (pad > 0);

        //allocate the WHOLE block
        blk->header.block_size = PACK(blk_size, 1, pbit);
        blk->header.hid = HEADER_MAGIC;
        blk->header.padding_amount = (uint64_t)pad;

        ics_footer *alloc_f = (ics_footer *)((char *)blk + blk_size - F);
        alloc_f->block_size = PACK(blk_size, 1, pbit);
        alloc_f->fid = FOOTER_MAGIC;
    }

    return (void *)((char *)blk + H);
}

static void write_epilogue(void) {
    char *brk = (char *)ics_get_brk();
    ics_header *epi = (ics_header *)(brk - sizeof(ics_header));

    epi->block_size = 0;
    epi->hid = HEADER_MAGIC;
    epi->padding_amount = 0;
}

static int is_in_freelist(ics_free_header *blk) {
    ics_free_header *curr = freelist_head;
    while (curr != NULL) {
        if (curr == blk) return 1;
        curr = curr->next;
    }
    return 0;
}

int grow_heap_one_page(void) {
    if (pages_allocated >= MAX_PAGES) {
        errno = ENOMEM;
        return -1;
    }

    void *new_page = ics_inc_brk();
    if (new_page ==((void *)-1)) return -1;

    pages_allocated++;

    //after increment, the old epilogue header is now at the start of the new space
    //Now we want to extend the ;ast real block if free
    char *old_brk = (char *)new_page;
    ics_footer *last_f = (ics_footer *)(old_brk - sizeof(ics_header) - sizeof(ics_footer));
    size_t last_size = GET_SIZE(last_f->block_size);

    //block start is at the end of the block so block start = (footer_addr - block_size + footer_size)
    ics_free_header *last_blk = (ics_free_header *)((char*)last_f - last_size + sizeof(ics_footer));

    //if the last block is free then it should be in the free list*****
    if (is_in_freelist(last_blk)) {
        //extend the last free block by one page
        size_t old_size = GET_SIZE(last_blk->header.block_size);
        size_t new_size = old_size + PAGE_SIZE;

        last_blk->header.block_size = PACK(new_size, 0, 0);
        last_blk->header.hid = HEADER_MAGIC;
        last_blk->header.padding_amount = 0;

        ics_footer *new_footer = (ics_footer *)((char *)last_blk + new_size - sizeof(ics_footer));
        new_footer->block_size = PACK(new_size, 0, 0);
        new_footer->fid = FOOTER_MAGIC;

        write_epilogue();
        return 0;
    }

    //OTHERWISE create a new free block out of the new page
    //header should start at teh OLD epilogue header location
    ics_free_header *fresh = (ics_free_header *)((char *)new_page - sizeof(ics_header));

    fresh->header.block_size = PACK(PAGE_SIZE, 0, 0);
    fresh->header.hid = HEADER_MAGIC;
    fresh->header.padding_amount = 0;

    fresh->next = NULL;
    fresh->prev = NULL;
    
    ics_footer *fresh_f = (ics_footer *)((char *)fresh + PAGE_SIZE - sizeof(ics_footer));
    fresh_f->block_size = PACK(PAGE_SIZE, 0, 0);;
    fresh_f->fid = FOOTER_MAGIC;

    //insert into freelist
    insert_free_block_ordered(fresh);

    write_epilogue();
    return 0;
}

int grow_heap_until_fit(size_t needed) {
    while (find_fit(needed) == NULL) {
        if (grow_heap_one_page() < 0) return -1;
    }
    return 0;
}

void insert_free_block_ordered(ics_free_header *blk) {
    size_t bsz = GET_SIZE(blk->header.block_size);

    blk->next = NULL;
    blk->prev = NULL;

    //empty check, if so then make this block the first in the list
    if (freelist_head == NULL) {
        freelist_head = blk;
        return;
    }

    ics_free_header *curr = freelist_head;

    while (curr != NULL) {
        size_t csz = GET_SIZE(curr->header.block_size);

        //largest to smallest insert before first block that is <= bsz while same size insert before
        if (csz < bsz || csz == bsz) {
            blk->next = curr;
            blk->prev = curr->prev;

            if (curr->prev != NULL) curr->prev->next = blk;
            else freelist_head = blk;

            curr->prev = blk;
            return;
        }
        curr = curr->next;
    }

    //smaller than all existing then just append to end
    curr = freelist_head;
    while (curr->next != NULL) curr = curr->next;

    curr->next = blk;
    blk->prev = curr;
}

int ptr_in_heap(void *ptr) {
    if (heap_start == NULL) return 0;
    char *lo = (char *)heap_start;
    char *hi = (char *)ics_get_brk();
    return ((char *)ptr > lo && (char *)ptr < hi);
}

int valid_allocated_block(void *ptr, ics_header **out_h, ics_footer **out_f) {
    if (ptr == NULL) return 0;

    //payload must be 16 byte aligned
    if (((uintptr_t)ptr % 16) != 0) return 0;

    if (!ptr_in_heap(ptr)) return 0;

    ics_header *h = (ics_header *)((char *)ptr - sizeof(ics_header));
    if(!ptr_in_heap(h)) return 0;

    if (h->hid != HEADER_MAGIC) return 0;

    size_t bsz = GET_SIZE(h->block_size);
    if (bsz == 0) return 0;

    ics_footer *f = (ics_footer *)((char *)h + bsz - sizeof(ics_footer));
    if(!ptr_in_heap(f)) return 0;

    if (f->fid != FOOTER_MAGIC) return 0;

    if (GET_SIZE(f->block_size) != bsz) return 0;

    //allocated bit must be set for the header and footer
    if (!GET_ALLOC(h->block_size)) return 0;
    if (!GET_ALLOC(f->block_size)) return 0;

    //if padding bit is set then padding amount should be greater than 0
    if (GET_PADBIT(h->block_size) && h->padding_amount == 0) return 0;

    *out_h = h;
    *out_f = f;
    return 1;
}

ics_free_header *coalesce(ics_header *h) {
    size_t F = sizeof(ics_footer);

    size_t bsz = GET_SIZE(h->block_size);
    ics_free_header *start = (ics_free_header *)h;

    //coalesce with the previous block
    ics_footer *prev_f = (ics_footer *)((char *)start - F);

    if (prev_f->fid == FOOTER_MAGIC) {
        size_t psz = GET_SIZE(prev_f->block_size);

        if (psz != 0) {
            ics_header *prev_h = (ics_header *)((char *)start - psz);
            if (prev_h->hid == HEADER_MAGIC && !GET_ALLOC(prev_h->block_size)) {
                ics_free_header *prev_blk = (ics_free_header *)prev_h;

                remove_free_block(prev_blk);

                start = prev_blk;
                bsz += psz;
            }
        }
    }

    //write merged free header/footer
    start->header.hid = HEADER_MAGIC;
    start->header.padding_amount = 0;
    start->header.block_size = PACK(bsz, 0, 0);

    ics_footer *new_f = (ics_footer *)((char *)start + bsz - F);
    new_f->fid = FOOTER_MAGIC;
    new_f->block_size = PACK(bsz, 0, 0);

    return start;
}
